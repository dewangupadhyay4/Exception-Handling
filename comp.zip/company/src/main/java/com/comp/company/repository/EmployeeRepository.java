package com.comp.company.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.comp.company.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
