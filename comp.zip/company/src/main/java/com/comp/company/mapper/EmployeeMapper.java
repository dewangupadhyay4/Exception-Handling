package com.comp.company.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.comp.company.dto.EmployeeDto;
import com.comp.company.entity.Employee;

@Component
public class EmployeeMapper {

	public static Employee toDto(EmployeeDto dto) {
		Employee emp=new Employee();
		emp.setId(dto.getId());
		emp.setName(dto.getName());
		emp.setEmail(dto.getEmail());
		emp.setPassword(dto.getPassword());
		emp.setRole(dto.getRole());
		return emp;
	}
	
	public static EmployeeDto toEntity(Employee emp) {
		EmployeeDto dto=new EmployeeDto();
		
		dto.setId(emp.getId());
		dto.setName(emp.getName());
		dto.setEmail(emp.getEmail());
		dto.setPassword(emp.getPassword());
		dto.setRole(emp.getRole());
		return dto;
	}
	
	public static List<EmployeeDto> toList(List<Employee> emp){
		List<EmployeeDto> list=new ArrayList<EmployeeDto>();
		for(Employee e:emp) {
			EmployeeDto dto=new EmployeeDto(
					e.getId(),
					e.getName(),
					e.getEmail(),
					e.getPassword(),
					e.getRole()
					
					);
			list.add(dto);
			
		}
		
		return list;
		
	}
	
}
