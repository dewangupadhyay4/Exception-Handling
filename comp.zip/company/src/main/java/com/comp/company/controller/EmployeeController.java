package com.comp.company.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.comp.company.dto.EmployeeDto;

public interface EmployeeController {
	
	public ResponseEntity<EmployeeDto> create(EmployeeDto dto);
	
	public ResponseEntity<List<EmployeeDto>> getAllOnce();
	
	public ResponseEntity<EmployeeDto> getViaId(Integer id);
	
	public ResponseEntity<EmployeeDto> update(Integer id,EmployeeDto dto);
	
	public void delete(Integer id);

}
